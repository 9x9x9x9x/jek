---
layout: post
title: About
---

This is an example page!

Actually, it has the same layout of a post...